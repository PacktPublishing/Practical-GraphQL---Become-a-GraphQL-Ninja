const userResolvers = require('./user');
const carResolvers = require('./car');

module.exports = [userResolvers, carResolvers];